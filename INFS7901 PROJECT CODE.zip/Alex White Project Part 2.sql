-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 12, 2024 at 04:23 AM
-- Server version: 8.0.36
-- PHP Version: 8.3.2-1+ubuntu20.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Alex Project`
--

-- --------------------------------------------------------

--
-- Table structure for table `ADMISSION`
--

CREATE TABLE `ADMISSION` (
  `PId` int NOT NULL,
  `WName` varchar(32) NOT NULL,
  `AdmitDate` date NOT NULL,
  `DischargeDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `ADMISSION`
--

INSERT INTO `ADMISSION` (`PId`, `WName`, `AdmitDate`, `DischargeDate`) VALUES
(1, 'Emergency', '2024-05-03', '2024-05-03'),
(2, 'Pediatrics', '2024-05-02', '2024-05-04'),
(3, 'Emergency', '2024-05-01', '2024-05-03'),
(4, 'Psychiatric', '2024-04-23', NULL),
(5, 'Surgical', '2024-04-26', NULL),
(6, 'Psychiatric', '2024-04-16', '2024-04-30'),
(7, 'Emergency', '2024-05-02', NULL),
(8, 'ICU', '2024-05-05', NULL),
(9, 'ICU', '2024-04-22', NULL),
(10, 'Emergency', '2024-04-22', NULL),
(11, 'Pediatrics', '2024-05-01', '2024-05-07'),
(12, 'Emergency', '2024-04-22', NULL),
(13, 'Emergency', '2024-04-23', NULL),
(14, 'Emergency', '2024-04-25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ASSIGNED`
--

CREATE TABLE `ASSIGNED` (
  `WName` varchar(32) NOT NULL,
  `SId` int NOT NULL,
  `DateStarted` date NOT NULL,
  `DateFinished` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `ASSIGNED`
--

INSERT INTO `ASSIGNED` (`WName`, `SId`, `DateStarted`, `DateFinished`) VALUES
('Emergency', 1, '2023-05-01', NULL),
('Emergency', 3, '2024-05-01', NULL),
('ICU', 2, '2022-05-03', NULL),
('ICU', 19, '2023-05-01', '2024-05-01'),
('Pediatrics', 5, '2023-05-01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `DOCTOR`
--

CREATE TABLE `DOCTOR` (
  `SId` int NOT NULL,
  `Type` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `DOCTOR`
--

INSERT INTO `DOCTOR` (`SId`, `Type`) VALUES
(1, 'Cardiologist'),
(2, 'Cardiologist'),
(3, 'Oncologist'),
(4, 'Neurologist'),
(5, 'Pediatrician');

-- --------------------------------------------------------

--
-- Table structure for table `GIVEN`
--

CREATE TABLE `GIVEN` (
  `SId` int NOT NULL,
  `MId` int NOT NULL,
  `PId` int NOT NULL,
  `TimeGiven` time NOT NULL,
  `DateGiven` date NOT NULL,
  `Dose` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `GIVEN`
--

INSERT INTO `GIVEN` (`SId`, `MId`, `PId`, `TimeGiven`, `DateGiven`, `Dose`) VALUES
(1, 6, 2, '19:37:21', '2024-05-01', '140mcg'),
(1, 6, 13, '19:44:38', '2024-05-02', '90mcg'),
(2, 6, 11, '19:51:37', '2024-05-03', '120mg'),
(4, 6, 4, '19:38:23', '2024-05-06', '100mcg'),
(5, 6, 6, '19:40:54', '2024-05-05', '90mcg'),
(5, 6, 10, '19:43:11', '2024-05-01', '90mcg'),
(7, 6, 3, '19:37:58', '2024-05-04', '120mcg'),
(13, 6, 1, '19:36:08', '2024-05-03', '120mcg'),
(15, 6, 14, '19:44:59', '2024-05-03', '100mcg'),
(15, 8, 11, '19:52:32', '2024-05-03', '120mcg'),
(17, 5, 6, '19:51:10', '2024-05-02', '100mg'),
(17, 6, 7, '19:39:47', '2024-05-08', '100mcg'),
(17, 6, 12, '19:43:40', '2024-05-02', '90mcg'),
(18, 3, 12, '19:50:32', '2024-05-01', '240mcg'),
(18, 6, 5, '19:39:23', '2024-05-07', '100mcg'),
(18, 6, 9, '19:41:59', '2024-05-06', '80mcg'),
(20, 6, 8, '19:41:26', '2024-05-07', '90mcg');

-- --------------------------------------------------------

--
-- Table structure for table `MEDICATION`
--

CREATE TABLE `MEDICATION` (
  `MId` int NOT NULL,
  `MedName` varchar(32) NOT NULL,
  `Brand` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `MEDICATION`
--

INSERT INTO `MEDICATION` (`MId`, `MedName`, `Brand`) VALUES
(1, 'Acetaminophen', 'Tylenol'),
(2, 'Acetaminophen', 'Panadol'),
(3, 'Albuterol', 'Ventolin'),
(4, 'Albuterol', 'ProAir'),
(5, 'Amoxicillin', 'Amoxil'),
(6, 'Ibuprofen', 'Nurofen'),
(7, 'Metformin', 'Axpinet'),
(8, 'Lisinopril', 'Zestril');

-- --------------------------------------------------------

--
-- Table structure for table `MED_TYPE`
--

CREATE TABLE `MED_TYPE` (
  `MedName` varchar(32) NOT NULL,
  `MedType` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `MED_TYPE`
--

INSERT INTO `MED_TYPE` (`MedName`, `MedType`) VALUES
('Acetaminophen', 'Analgesic'),
('Albuterol', 'Bronchodilator'),
('Amoxicillin', 'Antibiotic'),
('Ibuprofen', 'NSAID'),
('Lisinopril', 'ACE Inhibitor'),
('Metformin', 'Biguanide');

-- --------------------------------------------------------

--
-- Table structure for table `NURSE`
--

CREATE TABLE `NURSE` (
  `SId` int NOT NULL,
  `Level` varchar(32) NOT NULL,
  `Supervisor` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `NURSE`
--

INSERT INTO `NURSE` (`SId`, `Level`, `Supervisor`) VALUES
(1, 'Clinical Nurse Specialist', 17),
(2, 'Clinical Nurse Specialist', 17),
(3, 'Certified Nursing Assistant', 7),
(4, 'Registered Nurse', 10),
(5, 'Nurse Practitioner', 9),
(6, 'Certified Nursing Assistant', 7),
(7, 'Clinical Nurse Specialist', 11),
(8, 'Registered Nurse', 12),
(9, 'Registered Nurse', 16),
(10, 'Nurse Practitioner', 13),
(11, 'Certified Nursing Assistant', 15),
(12, 'Licensed Practical Nurse', 14),
(13, 'Certified Nursing Assistant', 20),
(15, 'Certified Nursing Assistant', 13);

-- --------------------------------------------------------

--
-- Table structure for table `PATIENT`
--

CREATE TABLE `PATIENT` (
  `PId` int NOT NULL,
  `PPhone` bigint DEFAULT NULL,
  `NextOfKin` varchar(32) DEFAULT NULL,
  `NokPhone` bigint DEFAULT NULL,
  `FName` varchar(32) NOT NULL,
  `LName` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `PATIENT`
--

INSERT INTO `PATIENT` (`PId`, `PPhone`, `NextOfKin`, `NokPhone`, `FName`, `LName`) VALUES
(1, 2499067624, 'John Doe', 3001953095, 'Chiquia', 'Penniall'),
(2, 2616056471, 'Jane Smith', 3906247362, 'Claudine', 'Guare'),
(3, 2904873218, 'Chris Brown', 6044335041, 'Harlene', 'Gladdifh'),
(4, 8795185857, 'Judy Dent', 3381326194, 'Robbert', 'Prattin'),
(5, 2446414741, 'Jeez Louise', 5488190763, 'Loria', 'Keat'),
(6, 7484530519, 'Phil Magroin', 3574238111, 'Deane', 'Allwright'),
(7, 6042757471, 'Michael Johnson', 9011935724, 'Flora', 'Winsborrow'),
(8, 9698688754, 'Pu Peh', 1703278396, 'Lia', 'Hriinchenko'),
(9, 9158471906, 'Tuchma Scrotum', 8588740041, 'Genni', 'Stenett'),
(10, 1336214778, 'Jeremy Phillis', 8987233555, 'Willi', 'Bracken'),
(11, 2365990916, 'Enid Cryton', 3312537925, 'Jephthah', 'Croad'),
(12, 3541622995, 'Jane Doe', 7097064119, 'Tully', 'Greg'),
(13, 4847332442, 'Chris Black', 8123996104, 'Jim', 'Anderbrugge'),
(14, 7709814022, 'Christopher Mung', 2011078598, 'Vincenty', 'Farragher');

-- --------------------------------------------------------

--
-- Table structure for table `PERFORMED`
--

CREATE TABLE `PERFORMED` (
  `SId` int NOT NULL,
  `PId` int NOT NULL,
  `ProcId` int NOT NULL,
  `PerfDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `PERFORMED`
--

INSERT INTO `PERFORMED` (`SId`, `PId`, `ProcId`, `PerfDate`) VALUES
(1, 3, 10, '2024-05-01'),
(3, 6, 9, '2024-05-05'),
(3, 8, 1, '2024-04-24'),
(2, 11, 4, '2024-05-03'),
(4, 11, 8, '2024-05-06'),
(2, 12, 1, '2024-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `PROCEDURE`
--

CREATE TABLE `PROCEDURE` (
  `ProcId` int NOT NULL,
  `BodyArea` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ProcType` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `PROCEDURE`
--

INSERT INTO `PROCEDURE` (`ProcId`, `BodyArea`, `ProcType`) VALUES
(1, 'Head', 'Sinus Surgery'),
(2, 'Head', 'Eye Surgery'),
(3, 'Head', 'Ear Surgery'),
(4, 'Head', 'Mouth Surgery'),
(5, 'Torso', 'Heart Surgery'),
(6, 'Torso', 'Lung Surgery'),
(7, 'Torso', 'Appendix Surgery'),
(8, 'Torso', 'Stomach Surgery'),
(9, 'Leg', 'Bone Surgery'),
(10, 'Arm', 'Bone Surgery'),
(11, 'Hand', 'Bone Surgery'),
(12, 'Foot', 'Bone Surgery');

-- --------------------------------------------------------

--
-- Table structure for table `STAFF`
--

CREATE TABLE `STAFF` (
  `SId` int NOT NULL,
  `SName` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `STAFF`
--

INSERT INTO `STAFF` (`SId`, `SName`) VALUES
(1, 'Andra Poetz'),
(2, 'Gwen Howerd'),
(3, 'Nils Skarman'),
(4, 'Georgianna Kingcott'),
(5, 'Colleen Humpherston'),
(6, 'Daryle Atteridge'),
(7, 'Annelise Hartell'),
(8, 'Melitta Pindell'),
(9, 'Riccardo Marchelli'),
(10, 'Ebonee Rivenzon'),
(11, 'Zenia Lissandri'),
(12, 'Gregorius Drysdell'),
(13, 'Adela Inkle'),
(14, 'Rhea Mulkerrins'),
(15, 'Marquita McQuaid'),
(16, 'Niels Tchaikovsky'),
(17, 'Fritz Vezey'),
(18, 'Billi Cheake'),
(19, 'Harlen Antoniazzi'),
(20, 'Helen Reckhouse');

-- --------------------------------------------------------

--
-- Table structure for table `WARD`
--

CREATE TABLE `WARD` (
  `WName` varchar(32) NOT NULL,
  `Type` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `WARD`
--

INSERT INTO `WARD` (`WName`, `Type`) VALUES
('Emergency', 'Emergency Care'),
('ICU', 'Emergency Care'),
('Pediatrics', 'Child Care'),
('Psychiatric', 'Mental Health Care'),
('Surgical', 'Surgical Care');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ADMISSION`
--
ALTER TABLE `ADMISSION`
  ADD PRIMARY KEY (`PId`,`WName`,`AdmitDate`),
  ADD KEY `WName` (`WName`);

--
-- Indexes for table `ASSIGNED`
--
ALTER TABLE `ASSIGNED`
  ADD PRIMARY KEY (`WName`,`SId`,`DateStarted`),
  ADD KEY `SId` (`SId`);

--
-- Indexes for table `DOCTOR`
--
ALTER TABLE `DOCTOR`
  ADD PRIMARY KEY (`SId`);

--
-- Indexes for table `GIVEN`
--
ALTER TABLE `GIVEN`
  ADD PRIMARY KEY (`SId`,`MId`,`PId`,`DateGiven`,`TimeGiven`),
  ADD KEY `MId` (`MId`),
  ADD KEY `PId` (`PId`);

--
-- Indexes for table `MEDICATION`
--
ALTER TABLE `MEDICATION`
  ADD PRIMARY KEY (`MId`),
  ADD KEY `MedName` (`MedName`);

--
-- Indexes for table `MED_TYPE`
--
ALTER TABLE `MED_TYPE`
  ADD PRIMARY KEY (`MedName`);

--
-- Indexes for table `NURSE`
--
ALTER TABLE `NURSE`
  ADD PRIMARY KEY (`SId`),
  ADD KEY `Supervisor` (`Supervisor`);

--
-- Indexes for table `PATIENT`
--
ALTER TABLE `PATIENT`
  ADD PRIMARY KEY (`PId`);

--
-- Indexes for table `PERFORMED`
--
ALTER TABLE `PERFORMED`
  ADD PRIMARY KEY (`SId`,`PId`,`ProcId`,`PerfDate`),
  ADD KEY `PId` (`PId`),
  ADD KEY `ProcId` (`ProcId`);

--
-- Indexes for table `PROCEDURE`
--
ALTER TABLE `PROCEDURE`
  ADD PRIMARY KEY (`ProcId`);

--
-- Indexes for table `STAFF`
--
ALTER TABLE `STAFF`
  ADD PRIMARY KEY (`SId`);

--
-- Indexes for table `WARD`
--
ALTER TABLE `WARD`
  ADD PRIMARY KEY (`WName`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ADMISSION`
--
ALTER TABLE `ADMISSION`
  ADD CONSTRAINT `ADMISSION_ibfk_1` FOREIGN KEY (`WName`) REFERENCES `WARD` (`WName`) ON DELETE CASCADE,
  ADD CONSTRAINT `ADMISSION_ibfk_2` FOREIGN KEY (`PId`) REFERENCES `PATIENT` (`PId`) ON DELETE CASCADE;

--
-- Constraints for table `ASSIGNED`
--
ALTER TABLE `ASSIGNED`
  ADD CONSTRAINT `ASSIGNED_ibfk_1` FOREIGN KEY (`WName`) REFERENCES `WARD` (`WName`) ON DELETE CASCADE,
  ADD CONSTRAINT `ASSIGNED_ibfk_2` FOREIGN KEY (`SId`) REFERENCES `STAFF` (`SId`) ON DELETE CASCADE;

--
-- Constraints for table `DOCTOR`
--
ALTER TABLE `DOCTOR`
  ADD CONSTRAINT `DOCTOR_ibfk_1` FOREIGN KEY (`SId`) REFERENCES `STAFF` (`SId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `GIVEN`
--
ALTER TABLE `GIVEN`
  ADD CONSTRAINT `GIVEN_ibfk_1` FOREIGN KEY (`SId`) REFERENCES `STAFF` (`SId`) ON DELETE CASCADE,
  ADD CONSTRAINT `GIVEN_ibfk_2` FOREIGN KEY (`MId`) REFERENCES `MEDICATION` (`MId`) ON DELETE CASCADE,
  ADD CONSTRAINT `GIVEN_ibfk_3` FOREIGN KEY (`PId`) REFERENCES `PATIENT` (`PId`) ON DELETE CASCADE;

--
-- Constraints for table `MEDICATION`
--
ALTER TABLE `MEDICATION`
  ADD CONSTRAINT `MEDICATION_ibfk_1` FOREIGN KEY (`MedName`) REFERENCES `MED_TYPE` (`MedName`);

--
-- Constraints for table `NURSE`
--
ALTER TABLE `NURSE`
  ADD CONSTRAINT `NURSE_ibfk_1` FOREIGN KEY (`SId`) REFERENCES `STAFF` (`SId`) ON DELETE CASCADE,
  ADD CONSTRAINT `NURSE_ibfk_2` FOREIGN KEY (`Supervisor`) REFERENCES `STAFF` (`SId`) ON DELETE SET NULL;

--
-- Constraints for table `PERFORMED`
--
ALTER TABLE `PERFORMED`
  ADD CONSTRAINT `PERFORMED_ibfk_1` FOREIGN KEY (`SId`) REFERENCES `STAFF` (`SId`) ON DELETE CASCADE,
  ADD CONSTRAINT `PERFORMED_ibfk_2` FOREIGN KEY (`PId`) REFERENCES `PATIENT` (`PId`) ON DELETE CASCADE,
  ADD CONSTRAINT `PERFORMED_ibfk_3` FOREIGN KEY (`ProcId`) REFERENCES `PROCEDURE` (`ProcId`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
